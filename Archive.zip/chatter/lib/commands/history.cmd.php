<?php

	// Recalling last input box content (message or command)
	if (isset($M1)) $M = $M1;
	else $M = $M0;

	$IsM = true;
	$IsCommand = true;

?>