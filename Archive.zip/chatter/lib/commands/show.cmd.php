<?php

$N = ($Cmd[3] != "") ? max(abs($Cmd[3]), 5) : 5;
$IsCommand = true;
$First = 1;
$RefreshMessages = true;
$CleanUsrTbl = 1;

?>