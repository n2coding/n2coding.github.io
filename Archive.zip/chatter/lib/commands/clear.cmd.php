<?php

//if ($Ver == "H")
//{
	$N = 5;
	$IsCommand = true;
	$First = 1;
	$RefreshMessages = true;
	$CleanUsrTbl = 1;
//}

?>