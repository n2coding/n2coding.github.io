<?php
define("APP_NAME", 'phpMyChat-Plus');					// Application name
define("APP_VERSION", '1.98');    						// Never modify/remove this line - it controls the update check up.
define("APP_MINOR", '');								// Never modify/remove this line - it controls the update check up.
define("RELEASE_DATE", '10 December 2019');				// Release date of this version
define("PLUS_DEVELOPER", 'Ciprian Murariu');			// Plus Developer name
define("PLUS_DEVELOPER_EMAIL", 'ciprianmp@yahoo.com');	// Plus Developer email
define("BASED_ON", 'phpMyChat 0.15.0 by Nick Hozey');	// Original standard version
define("PLUS_DEVELOPER_NEW", '');						// New Plus Developer name (after handover)
define("PLUS_DEVELOPER_EMAIL_NEW", '');					// New Plus Developer email (after handover)
?>