<a rel="license" href="https://creativecommons.org/licenses/by-nc-sa/3.0/" target="_blank" title="Creative Commons License">
<img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png" />
</a>