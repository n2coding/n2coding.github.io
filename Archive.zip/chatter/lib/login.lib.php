<?php
if (is_array($_SESSION)) { }
else
{
	ini_set('session.bug_compat_42',0);
	ini_set('session.bug_compat_warn',0);
	ini_set('session.use_trans_sid',1);
	ini_set('session.use_cookies',1);
	session_start();
//	session_register("adminlogged");
	$_SESSION['adminlogged'] = true;
}

// Added for Skin mod
if (isset($_COOKIE["CookieRoom"])) $R = urldecode($_COOKIE["CookieRoom"]);
if (isset($_COOKIE["CookieHash"])) $RemMe = $_COOKIE["CookieHash"];
require("./config/config.lib.php");

$DbLink4Login = new DB;
if (isset($_COOKIE["CookieUsername"]))
{
//	$pmc_username = urldecode($_COOKIE["CookieUsername"]);
	$FOCUS = 1;
}

if ((isset($pmc_username) && $pmc_username != "") && (isset($pmc_password) && $pmc_password != ""))
{
	// Ensure the password is a correct one
	$do_not_login = false;
	$DbLink4Login->query("SELECT password,perms,email FROM ".C_REG_TBL." WHERE username='$pmc_username' LIMIT 1");
	if ($DbLink4Login->num_rows() != 0)
	{
		list($PWD_Hash, $perms, $pmc_email) = $DbLink4Login->next_record();
		if ($PWD_Hash == md5(stripslashes($pmc_password)) || $PWD_Hash == $pmc_password)
		{
			// Ensure the one who lauch the admin.php script is really admin
			if (isset($MUST_BE_ADMIN) && $perms != "admin")
			{
				$Error = L_ERR_USR_11;
			}
			else
			{
				$do_not_login = true;
				$_SESSION["adminlogged"] = true;
			}
		}
	}
	else if (isset($perms))
	{
		unset($perms);
	}
	$DbLink4Login->clean_results();
	$DbLink4Login->close();
}

// If no login yet entered
if (!isset($do_not_login) || !$do_not_login)
{

// Special cache instructions for IE5+
$CachePlus	= "";
#if (ereg("MSIE [56789]", (isset($HTTP_USER_AGENT)) ? $HTTP_USER_AGENT : getenv("HTTP_USER_AGENT"))) $CachePlus = ", pre-check=0, post-check=0, max-age=0";
if (stripos((isset($HTTP_USER_AGENT)) ? $HTTP_USER_AGENT : getenv("HTTP_USER_AGENT"), "MSIE") !== false) $CachePlus = ", pre-check=0, post-check=0, max-age=0";
$now		= gmdate('D, d M Y H:i:s') . ' GMT';

header("Expires: $now");
header("Last-Modified: $now");
header("Cache-Control: no-cache, must-revalidate".$CachePlus);
header("Pragma: no-cache");
header("Content-Type: text/html; charset=${Charset}");

// avoid server configuration for magic quotes
if(function_exists('set_magic_quotes_runtime') && version_compare(PHP_VERSION, '5.3.0') < 0) set_magic_quotes_runtime(0);
else ini_set("magic_quotes_runtime", 0);
// Can't turn off magic quotes gpc so just redo what it did if it is on.
if (function_exists('get_magic_quotes_gpc') && @get_magic_quotes_gpc()) {
	foreach($_GET as $k=>$v)
		$_GET[$k] = stripslashes($v);
	foreach($_POST as $k=>$v)
		$_POST[$k] = stripslashes($v);
	foreach($_COOKIE as $k=>$v)
		$_COOKIE[$k] = stripslashes($v);
}

if (isset($login_form))
{
	if (!isset($Error)) $Error = L_ERR_USR_10;
	unset($pmc_email);
	unset($pmc_password);
	unset($pmc_username);
	$LIMIT = 0;
}

// If this script is lauch by a profile command, put focus to the password field
$Focus = ((isset($LIMIT) && $LIMIT) || (isset($FOCUS) && $FOCUS)) ? "pmc_password" : "pmc_username";

// For translations with an explicit charset (not the 'x-user-defined' one)
if (!isset($FontName)) $FontName = "";
?>
<!DOCTYPE html>
<HTML dir="<?php echo(($Align == "right") ? "RTL" : "LTR"); ?>">

<HEAD>
<TITLE><?php echo((C_CHAT_NAME != "") ? C_CHAT_NAME : APP_NAME); ?></TITLE>
<LINK REL="stylesheet" HREF="<?php echo($skin.".css.php?Charset=${Charset}&medium=${FontSize}&FontName=".urlencode($FontName)); ?>" TYPE="text/css">
<SCRIPT TYPE="text/javascript" LANGUAGE="JavaScript1.1">
<!--
function get_focus()
{
	window.focus();
	document.forms['LoginForm'].elements['<?php echo($Focus); ?>'].focus();
}
// -->

	// Open popups for registration stuff
	function reg_popup(name)
	{
	if (name == "register") var u_name = "&U=";
	else var u_name = "&pmc_username=";
	if (name == "admin") var link = "&Link=1";
	else var link = "";
		window.focus();
		url = '<?php echo("${ChatPath}"); ?>' + name + '<?php echo(".php?L=$L"); ?>' + u_name + '<?php echo(urlencode(stripslashes($pmc_username))."&LIMIT=1"); ?>' + link;
		pop_width = 470;
		pop_height = 260;
		param = "width=" + pop_width + ",height=" + pop_height + ",resizable=yes,scrollbars=yes";
		name += "_popup";
		window.open(url,name,param);
	}
</SCRIPT>
</HEAD>

<BODY onLoad="if (window.focus) get_focus();">
<CENTER>
<br />
<?php
// Get the name of the script that called the login library
if (!isset($PHP_SELF)) $PHP_SELF = $_SERVER["SCRIPT_NAME"];
$From = basename($PHP_SELF);
?>
<FORM ACTION="<?php echo($From); ?>" METHOD="POST" AUTOCOMPLETE="" NAME="LoginForm">
<P></P>
<?php
if(isset($Error))
{
	echo("<P><SPAN CLASS=\"error\">$Error</SPAN></P>");
}
$CellAlign = ($Align == "right" ? "RIGHT" : "LEFT");
?>
<INPUT TYPE="hidden" NAME="L" VALUE="<?php echo($L); ?>">
<INPUT TYPE="hidden" NAME="Link" VALUE="<?php if (isset($Link)) echo($Link); ?>">
<INPUT TYPE="hidden" NAME="LIMIT" VALUE="<?php if (isset($LIMIT)) echo($LIMIT); ?>">
<TABLE ALIGN="center" BORDER=0 CELLPADDING=3 CLASS="table">
<TR>
	<TD ALIGN="CENTER">
		<TABLE BORDER=0>
		<TR>
			<TH COLSPAN=2 CLASS="tabtitle"><?php echo(L_REG_14); ?></TH>
		</TR>
		<TR>
			<TD ALIGN="<?php echo($CellAlign); ?>" VALIGN="TOP" NOWRAP="NOWRAP"><?php echo(L_SET_2); ?> :</TD>
			<TD ALIGN="<?php echo($CellAlign); ?>" VALIGN="TOP">
				<INPUT TYPE="text" NAME="pmc_username" SIZE=11 MAXLENGTH=15 VALUE="<?php if (isset($pmc_username)) echo(htmlspecialchars(stripslashes($pmc_username))); ?>">
			</TD>
		</TR>
		<TR>
			<TD ALIGN="<?php echo($CellAlign); ?>" VALIGN="TOP" NOWRAP="NOWRAP"><?php echo(L_REG_1); ?> :</TD>
			<TD ALIGN="<?php echo($CellAlign); ?>" VALIGN="TOP">
				<INPUT TYPE="password" NAME="pmc_password" SIZE=11 MAXLENGTH=16 VALUE="<?php echo($RemMe ? $RemMe : ((isset($pmc_password)) ? htmlspecialchars(stripslashes($pmc_password)) : "")); ?>">
				</TD>
		</TR>
		<TR>
			<TD ALIGN="<?php echo($CellAlign); ?>" VALIGN="TOP" NOWRAP="NOWRAP"></TD>
			<TD ALIGN="<?php echo($CellAlign); ?>" VALIGN="TOP">
				<A HREF="<?php echo(${ChatPath}); ?>pass_reset.php?L=<?php echo($L); ?>" CLASS="ChatReg" onClick="reg_popup('pass_reset'); return false" TARGET="_blank" onMouseOver="window.status='<?php echo(L_PASS_7); ?>.'; return true;"><?php echo(L_PASS_7); ?></A>
			</TD>
		</TR>
		</TABLE>
		<P>
		<INPUT TYPE="submit" NAME="login_form" VALUE="<?php echo(L_REG_15); ?>">
	</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
</BODY>

</HTML>
<?php
exit;

} // if(!isset($do_not_login))
?>