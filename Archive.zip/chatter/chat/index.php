<?php
?>
<html>
<head>
<title>Our chat has moved to a new location</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<LINK REL="stylesheet" HREF="../skins/style5.css.php" TYPE="text/css">
</head>
<body class="frame">
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><center><font size="+2"><b>Our chat has moved to a new location.<br />Please update your Bookmark (Favorite) by pressing Ctrl+D on the next page<br />Press <a href=../>here</a> to go to the index page or just wait...</b><font>
<br /><br /><br /><br />Redirection to the index page in 10 seconds.</center>
<meta http-equiv="refresh" content="5; url=../">
</body>
</html>
<?php
?>