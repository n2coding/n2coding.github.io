<?php
// "EverGreen" skin for phpMyChat plus - by Ealdwulf

$SKIN_NAME = "EverGreen";
$SKIN_DATE = "2006-".(date('Y'));
$SKIN_BY = "Ealdwulf";
$COLOR_BK = "DarkGreen"; //main background color
$COLOR_BODY = "Honeydew"; //main body color
$COLOR_TB = "Honeydew"; //main table color
$COLOR_SCROLL_TRACK = "ForestGreen"; //main table color
$COLOR_LINK = "Ivory"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "PowderBlue"; //highlight background color
define("COLOR_CD", "green"); //default messages color (also the filter color of this room)
?>