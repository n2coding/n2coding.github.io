<?php
// "SteelBricks" skin for phpMyChat plus - by Charles from IPM Chat, based on Ealdwulf's SteelBlue skin

$SKIN_NAME = "SteelBricks";
$SKIN_DATE = "2010".((date('Y')>"2010") ? "-".date('Y') : "");
$SKIN_BY = "Charles";
$COLOR_BK = "SteelBlue"; //main background color
$COLOR_BODY = "MistyRose"; //main body color
$COLOR_TB = "LightBlue"; //main table color
$COLOR_SCROLL_TRACK = "NavajoWhite"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "DimGray"; //highlight background color
define("COLOR_CD", "white"); //default messages color (also the filter color of this room)
?>