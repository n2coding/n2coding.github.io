<?php
// "Dark Embrace" skin for phpMyChat plus - by DarkPoet

$SKIN_NAME = "Dark Embrace";
$SKIN_DATE = "2009".((date('Y')>"2009") ? "-".date('Y') : "");
$SKIN_BY = "Jerome";
$COLOR_BK = "Black"; //default background color
$COLOR_BODY = "Black"; //default body color
$COLOR_TB = ""; //default table color
$COLOR_SCROLL_TRACK = "Slategrey"; //main table color
$COLOR_LINK = "Sienna"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "DimGray"; //highlight background color
define("COLOR_CD", "white"); //default messages color (also the filter color of this room)
?>