<?php
// "OrangeVisions" skin for phpMyChat plus - by Ciprian

$SKIN_NAME = "OrangeVisions";
$SKIN_DATE = "2011".((date('Y')>"2011") ? "-".date('Y') : "");
$SKIN_BY = "Ciprian";
$COLOR_BK = "#FE9D00"; //main background color
$COLOR_BODY = "black"; //main body color
$COLOR_TB = "wheat"; //main table color
$COLOR_SCROLL_TRACK = "#FE9D00"; //main table color
$COLOR_LINK = "brown"; //main table color
$COLOR_TOPIC = "brown"; //topic color
$COLOR_HIGH = "Snow"; //highlight background color
define("COLOR_CD", "black"); //default messages color (also the filter color of this room)
?>