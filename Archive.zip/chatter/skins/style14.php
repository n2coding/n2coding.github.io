<?php
// "Flights of Fancy" skin for phpMyChat plus - by DarkPoet

$SKIN_NAME = "Flights of Fancy";
$SKIN_DATE = "2008".((date('Y')>"2008") ? "-".date('Y') : "");
$SKIN_BY = "DarkPoet";
$COLOR_BK = "DimGray"; //default background color
$COLOR_BODY = ""; //default body color
$COLOR_TB = ""; //default table color
$COLOR_SCROLL_TRACK = "RoyalBlue"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "MediumBlue"; //highlight background color
define("COLOR_CD", "lightsteelblue"); //default messages color (also the filter color of this room)
?>