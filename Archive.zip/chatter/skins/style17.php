<?php
// "Bar n Grill" skin for phpMyChat plus - by DarkPoet

$SKIN_NAME = "Bar n Grill";
$SKIN_DATE = "2008".((date('Y')>"2008") ? "-".date('Y') : "");
$SKIN_BY = "DarkPoet";
$COLOR_BK = "SaddleBrown"; //default background color
$COLOR_BODY = "SaddleBrown"; //default body color
$COLOR_TB = ""; //default table color
$COLOR_SCROLL_TRACK = "Chocolate"; //main table color
$COLOR_LINK = "Sienna"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "BurlyWood"; //highlight background color
define("COLOR_CD", "ivory"); //default messages color (also the filter color of this room)
?>