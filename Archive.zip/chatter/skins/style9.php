<?php
// "Dark Purple" skin for phpMyChat plus by Ealdwulf

$SKIN_NAME = "DarkPurple";
$SKIN_DATE = "2000-".(date('Y'));
$SKIN_BY = "Ealdwulf";
$COLOR_SCROLL_TRACK = "NavajoWhite"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Snow"; //highlight background color
define("COLOR_CD", "blueviolet"); //default messages color (also the filter color of this room)
?>