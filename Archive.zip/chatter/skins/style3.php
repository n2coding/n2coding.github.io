<?php
// "Dark Shadows" skin for phpMyChat plus - by Ealdwulf

$SKIN_NAME = "Dark Shadows";
$SKIN_DATE = "2006-".(date('Y'));
$SKIN_BY = "Ealdwulf";
$COLOR_BK = "#404040"; //default background color
$COLOR_BODY = "Khaki"; //default body color
$COLOR_TB = "LightGrey"; //default table color
$COLOR_SCROLL_TRACK = "Gray"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Snow"; //highlight background color
define("COLOR_CD", "dimgray"); //default messages color (also the filter color of this room)
?>