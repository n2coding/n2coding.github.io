<?php
// "White Rose" skin for phpMyChat plus - by DarkPoet

$SKIN_NAME = "White Rose";
$SKIN_DATE = "2008".((date('Y')>"2008") ? "-".date('Y') : "");
$SKIN_BY = "DarkPoet";
$COLOR_BK = "FloralWhite"; //default background color
$COLOR_BODY = "PaleGreen"; //ForestGreen default body color
$COLOR_TB = "PaleGreen"; //SeaGreen default table color
$COLOR_SCROLL_TRACK = "LightGrey"; //main table color
$COLOR_LINK = "DarkGreen"; //links color
$COLOR_TOPIC = "OrangeRed"; //topic color
$COLOR_HIGH = "Gainsboro"; //highlight background color
define("COLOR_CD", "green"); //default messages color (also the filter color of this room)
?>