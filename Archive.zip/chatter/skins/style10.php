<?php
// "SlateBlue (Standard)" skin for phpMyChat plus - by phpHeaven Team

$SKIN_NAME = "SlateBlue (Standard)";
$SKIN_DATE = "2000-".(date('Y'));
$SKIN_BY = "phpHeaven Team";
$COLOR_SCROLL_TRACK = "NavajoWhite"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Snow"; //highlight background color
define("COLOR_CD", "navy"); //default messages color (also the filter color of this room)
?>