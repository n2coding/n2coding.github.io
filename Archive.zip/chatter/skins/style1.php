<?php
// "SteelBlue (Default)" skin for phpMyChat plus - by Ealdwulf

$SKIN_NAME = "SteelBlue (Default)";
$SKIN_DATE = "2006-".(date('Y'));
$SKIN_BY = "Ealdwulf";
$COLOR_BK = "SteelBlue"; //main background color
$COLOR_BODY = "MistyRose"; //main body color
$COLOR_TB = "LightBlue"; //main table color
$COLOR_SCROLL_TRACK = "NavajoWhite"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Snow"; //highlight background color
define("COLOR_CD", "black"); //default messages color (also the filter color of this room)
?>