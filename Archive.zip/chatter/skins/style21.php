<?php
// "Crush" skin for phpMyChat plus - by The Web Styles

$SKIN_NAME = "Crush";
$SKIN_DATE = "2011".((date('Y')>"2011") ? "-".date('Y') : "");
$SKIN_BY = "The Web Styles";
$COLOR_BK = "#FC9612"; //Orange main background color
$COLOR_BODY = "#E7DED6"; //main body color
$COLOR_TB = "#77524A"; //main table color
$COLOR_SCROLL_TRACK = "NavajoWhite"; //main table color
$COLOR_LINK = "#F7F3D3"; //main table color
$COLOR_TOPIC = "#D67A7F"; //topic color
$COLOR_HIGH = "#FFFAFA"; //highlight background color
define("COLOR_CD", "black"); //default messages color (also the filter color of this room)
?>