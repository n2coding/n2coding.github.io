<?php
// "Dungeon" skin for phpMyChat plus - by DarkPoet

$SKIN_NAME = "Dungeon";
$SKIN_DATE = "2008".((date('Y')>"2008") ? "-".date('Y') : "");
$SKIN_BY = "DarkPoet";
$COLOR_BK = "DimGray"; //default background color
$COLOR_BODY = "DimGray"; //default body color
$COLOR_TB = ""; //default table color
$COLOR_SCROLL_TRACK = "Silver"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "SlateGray"; //highlight background color
define("COLOR_CD", "gainsboro"); //default messages color (also the filter color of this room)
?>