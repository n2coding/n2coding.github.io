<?php
// "DarkSlateBlue" skin for phpMyChat plus - by Ealdwulf

$SKIN_NAME = "DarkSlateBlue";
$SKIN_DATE = "2006-".(date('Y'));
$SKIN_BY = "Ealdwulf";
$COLOR_BK = "DarkSlateBlue"; //main background color
$COLOR_BODY = "Lavender"; //main body color
$COLOR_TB = "Lavender"; //main table color
$COLOR_SCROLL_TRACK = "BlueViolet"; //main table color
$COLOR_LINK = "Ivory"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Khaki"; //highlight background color
define("COLOR_CD", "indigo"); //default messages color (also the filter color of this room)
?>