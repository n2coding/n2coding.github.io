<?php
// "Black & white" skin for phpMyChat plus - by BluntDog

$SKIN_NAME = "Black & white";
$SKIN_DATE = "2006-".(date('Y'));
$SKIN_BY = "BluntDog";
$COLOR_SCROLL_TRACK = "NavajoWhite"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Gray"; //highlight background color
define("COLOR_CD", "white"); //default messages color (also the filter color of this room)
?>