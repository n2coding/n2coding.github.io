<?php
// "Twinkle Twinkle" skin for phpMyChat plus - by DarkPoet

$SKIN_NAME = "Twinkle Twinkle";
$SKIN_DATE = "2008".((date('Y')>"2008") ? "-".date('Y') : "");
$SKIN_BY = "DarkPoet";
$COLOR_BK = "Black"; //default background color
$COLOR_BODY = "Black"; //default body color
$COLOR_TB = ""; //default table color
$COLOR_SCROLL_TRACK = "darkslateblue"; //main table color
$COLOR_LINK = "Blue"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "DarkSlateGray"; //highlight background color
define("COLOR_CD", "lightsteelblue"); //default messages color (also the filter color of this room)
?>