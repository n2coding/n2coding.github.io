<?php
// "DarkRed" skin for phpMyChat plus - by Ealdwulf

$SKIN_NAME = "DarkRed";
$SKIN_DATE = "2006-".(date('Y'));
$SKIN_BY = "Ealdwulf";
$COLOR_BK = "DarkRed"; //main background color
$COLOR_BODY = "LavenderBlush"; //main body color
$COLOR_TB = "LavenderBlush"; //main table color
$COLOR_SCROLL_TRACK = "Firebrick"; //main table color
$COLOR_LINK = "Ivory"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Khaki"; //highlight background color
define("COLOR_CD", "brown"); //default messages color (also the filter color of this room)
?>