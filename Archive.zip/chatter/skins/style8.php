<?php
// "White & black" skin for phpMyChat plus - by Ciprian

$SKIN_NAME = "White & black";
$SKIN_DATE = "2008".((date('Y')>"2008") ? "-".date('Y') : "");
$SKIN_BY = "Ciprian";
$COLOR_SCROLL_TRACK = "NavajoWhite"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "LightGrey"; //highlight background color
define("COLOR_CD", "black"); //default messages color (also the filter color of this room)
?>