<?php
// "Firebrick" skin for phpMyChat plus - by Ealdwulf

$SKIN_NAME = "Firebrick";
$SKIN_DATE = "2006-".(date('Y'));
$SKIN_BY = "Ealdwulf";
$COLOR_BK = "Firebrick"; //default background color
$COLOR_BODY = "Gold"; //default body color
$COLOR_TB = "Cornsilk"; //default table color
$COLOR_SCROLL_TRACK = "Red"; //main table color
$COLOR_LINK = "Khaki"; //default table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Khaki"; //highlight background color
define("COLOR_CD", "tomato"); //default messages color (also the filter color of this room)
?>