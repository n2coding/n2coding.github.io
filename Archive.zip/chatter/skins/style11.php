<?php
// "Pink & magenta" skin for phpMyChat plus - by Ciprian

$SKIN_NAME = "Magenta";
$SKIN_DATE = "2006-".(date('Y'));
$SKIN_BY = "Ciprian";
$COLOR_SCROLL_TRACK = "NavajoWhite"; //main table color
$COLOR_LINK = "Khaki"; //main table color
$COLOR_TOPIC = "Yellow"; //topic color
$COLOR_HIGH = "Snow"; //highlight background color
define("COLOR_CD", "magenta"); //default messages color (also the filter color of this room)
?>