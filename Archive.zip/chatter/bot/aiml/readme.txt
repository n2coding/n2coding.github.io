These AIML files are provided so you can test Program E to make sure it is functional. Your bot will not be very smart with just these files loaded.

You can find more AIML sets that work well with Program E by going to http://sourceforge.net/project/showfiles.php?group_id=43190

No matter what AIML files you use you should use the startup.xml file provided here as your starting point for your own startup.xml. In this file you can define your bot's personality.

Remove the aiml sets you don't want your bot to learn (ex. Religion.aiml contains only the Protestant Christian religious remarks)

Of course, you can build your own aiml sets, using the tools available at http://www.alicebot.org

For questions related to phpMyChat-Plus intergation and Program E, contact Ciprian M. at ciprianmp@yahoo.com.