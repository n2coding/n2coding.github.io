<?php
// This file has been declared as deprecated. It stays here only for old bookmarks users might have pointing to this file
require("index.php");
?>