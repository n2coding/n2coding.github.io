<?php
// Chat Extras panel by DigiozMultimedia
// This sheet is diplayed when the admin wants to check/view/delete messages from the chat

if ($_SESSION["adminlogged"] != "1") exit(); // added by Bob Dickow for security.

if (!C_CHAT_EXTRAS)
{
?>
<P CLASS=title><?php echo(APP_NAME." ".A_EXTR_DSBL) ; ?></P>
<?php
}
else
{
// Credit for this goes to Pete Soheil <webmaster@digioz.com>
$pstr = "admin.php?From=admin.php&What=Body&L=".$L."&pmc_username=".$pmc_username."&pmc_password=".$pmc_password."&sheet=6";
$mdel = $_GET['mdel'];
$mord = $_GET['mord'];

if($mord == "")
{
     $sqlT = " ORDER BY m_time DESC;";
}
else if($mord == "F")
{
     $sqlT = " ORDER BY username ASC;";
}
else if($mord == "R")
{
     $sqlT = " ORDER BY room ASC;";
}
else if($mord == "M")
{
     $sqlT = " ORDER BY message ASC;";
}
else
{
     $sqlT = " ORDER BY m_time DESC;";
}

if($mdel != "")
{
    $DbLink->query("DELETE FROM ".C_MSG_TBL." WHERE m_time='".$mdel."'");
}

// View List of Current Chat (HIDDEN and VISIBLE) ------------------------------------------------------

$DbLink->query("SELECT room,username,address,message,m_time FROM ".C_MSG_TBL."".$sqlT);

echo "<a href=\"$pstr&mdel=\"><b><font color=white>".A_REFRESH_MSG."</font></b></a></center><br />";
echo "<table align=\"center\" border=\"0\" cellpadding=\"1\" cellspacing=\"1\" width=\"98%\" CLASS=table>";
echo "<tr CLASS=\"tabtitle\">
<td VALIGN=CENTER ALIGN=CENTER height=20 CLASS=tabtitle align=center><b>".A_MSG_DEL."</b></a></td>
<td VALIGN=CENTER ALIGN=CENTER height=20 CLASS=tabtitle align=center><a href=\"$pstr&mord=T\"><b>".A_POST_TIME."</b></a></td>
<td VALIGN=CENTER ALIGN=CENTER height=20 CLASS=tabtitle align=center nowrap=nowrap><a href=\"$pstr&mord=F\"><b>".A_FROM_TO."</b></a></td>
<td VALIGN=CENTER ALIGN=CENTER height=20 CLASS=tabtitle align=center><a href=\"$pstr&mord=R\"><b>".A_CHTEX_ROOM."</b></a></td>
<td VALIGN=CENTER ALIGN=CENTER height=20 CLASS=tabtitle align=center><a href=\"$pstr&mord=M\"><b>".A_CHTEX_MSG."</b></a></td>
</tr>";

while(list($room, $username, $address, $message, $m_time) = $DbLink->next_record())
{
#$room = stripslashes($result["room"]);
#$username = stripslashes($result["username"]);
#$address = stripslashes($result["address"]);
if ($address != "") $address = " to <b>".$address."";
#$message = stripslashes($result["message"]);
#if (C_POPUP_LINKS || eregi('target="_blank"></a>',$message))
if (C_POPUP_LINKS || stripos($message,'target="_blank"></a>') !== false)
{
	$message = str_replace('target="_blank"></a>','title="'.sprintf(L_CLICKS,L_LINKS_15,L_LINKS_1).'" onMouseOver="window.status=\''.sprintf(L_CLICKS,L_LINKS_15,L_LINKS_1).'.\'; return true" target="_blank">'.sprintf(L_CLICKS,L_LINKS_15,L_LINKS_1).'</a>',$message);
}
else $message = str_replace('target="_blank">','title="'.sprintf(L_CLICK,L_LINKS_3).'" onMouseOver="window.status=\''.sprintf(L_CLICK,L_LINKS_3).'.\'; return true" target="_blank">',$message);
$message = str_replace('alt="Send email">','title="'.sprintf(L_CLICK,L_EMAIL_1).'" onMouseOver="window.status=\''.sprintf(L_CLICK,L_EMAIL_1).'.\'; return true">',$message);
#$m_time = stripslashes($result["m_time"]);
$time_posted = strftime(L_SHORT_DATETIME, $m_time);
if(stristr(PHP_OS,'win') && (strstr($L,"chinese") || strstr($L,"korean") || strstr($L,"japanese"))) $time_posted = str_replace(" ","",$time_posted);

echo "<tr class=\"msg2\">
<td width=1% align=center><a href=\"$pstr&mord=$mord&mdel=".$m_time."\"><font size=-2 color=red><b>x</b></font></a></td>
<td width=1% align=center>".$time_posted."</td>
<td width=1%><b>$username</b>".$address."</b>:</td>
<td width=1%>".$room."</td>
<td>".$message."</td></tr>";
}

echo "</table><br />";
$DbLink->clean_results();
}
?>