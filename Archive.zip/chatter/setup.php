<html>
<head>
<title>phpMyChat-Plus - Installer setup</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<LINK REL="stylesheet" HREF="./config/style1.css.php" TYPE="text/css">
</head>

<body class="frame">
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><center><table align="center"><tr><td><font size="+2"><b>phpMyChat-Plus Installer setup will start in 3 seconds.</b><font></td></tr></table></center>
<meta http-equiv="refresh" content="3; url=./install/install.php">
</body>
</html>