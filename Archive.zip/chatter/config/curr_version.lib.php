<?php
// Do NOT remove this file!
// App current version values for future upgrade purposes.
// This file had been created/updated by the installer.
define("APP_CURR_VERSION", '1.97');
define("APP_CURR_MINOR", '');	// E.g. "-ß1"
?>